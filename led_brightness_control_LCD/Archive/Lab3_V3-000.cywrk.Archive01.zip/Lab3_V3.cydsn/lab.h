#ifndef LAB_H
#define LAB_H
    
    //Підключення всіх файлів з розширенням .h
    #include "project.h"
    #include "algorithm.h"
    #include "protocol.h" 
    #include "lcd_traffic_light.h"
    
#endif