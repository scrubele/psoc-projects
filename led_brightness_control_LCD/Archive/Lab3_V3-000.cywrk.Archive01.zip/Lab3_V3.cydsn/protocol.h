#ifndef PROTOCOL_H
#define PROTOCOL_H
    
    //Прототипи функцій з файлу protocol.c
    void protocol_init(void);
    
#endif 