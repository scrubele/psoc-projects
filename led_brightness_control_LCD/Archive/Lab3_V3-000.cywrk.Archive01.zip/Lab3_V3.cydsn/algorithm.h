#ifndef ALGORITHM
#define ALGORITHM
    
    //Прототипи функцій з файлу algorithm.c
    void algorithm_init(void);
    void algorithm_definition(void);

#endif