#ifndef LCD_TRAFFIC_LIGHT_H
#define LCD_TRAFFIC_LIGHT_H
    
    //Прототипи функцій з файлу lcd_traffic_light.c
    void lcd_init(void);
    void enc_init(void);
    void definition_set_color(void);

#endif